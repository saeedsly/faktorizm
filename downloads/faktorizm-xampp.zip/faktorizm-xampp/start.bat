@echo off
chcp 65001 >nul
title فاکتوریزم — سرور برنامه
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js نصب نیست. ابتدا آن را از https://nodejs.org نصب کنید.
  pause
  exit /b 1
)

if not exist "server\node_modules" (
  echo ابتدا یک بار فایل setup.bat را برای نصب اولیه اجرا کنید.
  pause
  exit /b 1
)

echo ============================================================
echo   فاکتوریزم در حال راه‌اندازی است ...
echo   آدرس برنامه: http://localhost:8787
echo   برای توقف سرور، همین پنجره را ببندید یا Ctrl+C بزنید.
echo ============================================================
echo.

rem بعد از چند ثانیه مرورگر به‌صورت خودکار باز می‌شود
start "open-browser" /min cmd /c "timeout /t 4 /nobreak >nul && start """" http://localhost:8787"

rem بارگذاری متغیرهای محیطی و اجرای سرور (نیازمند Node 20.12 یا بالاتر)
node --env-file=.env server/src/index.js

echo.
echo سرور متوقف شد.
pause
