@echo off
setlocal enableextensions
title Faktorizm - Server
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get the LTS version from https://nodejs.org
  pause
  exit /b 1
)

if not exist "server\node_modules" (
  echo First run setup.bat once to complete the installation.
  pause
  exit /b 1
)

rem Start the local Python OCR engine in a minimized window (optional).
rem If it is missing, the app silently falls back to the browser OCR engine.
if exist "ocr-service\.venv\Scripts\python.exe" (
  if exist "ocr-service\service.py" (
    start "Faktorizm OCR Engine" /min cmd /c ""%~dp0ocr-service\.venv\Scripts\python.exe" "%~dp0ocr-service\service.py""
    timeout /t 2 /nobreak >nul
  )
)

echo ============================================================
echo   Starting Faktorizm ...
echo.
echo   App URL : http://localhost:8787
echo.
echo   Keep this window open while using the app.
echo   To stop: close this window or press Ctrl+C.
echo ============================================================
echo.

rem Open the browser automatically after a few seconds
start "" /min cmd /c "timeout /t 4 /nobreak >nul & explorer http://localhost:8787"

rem Load variables from .env and start the server (requires Node 20.12 or newer)
node --env-file=.env server/src/index.js

echo.
echo Server stopped.
pause
