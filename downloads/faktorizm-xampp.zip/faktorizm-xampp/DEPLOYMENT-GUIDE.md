# راهنمای جامع فاکتوریزم — تصمیم فنی و استقرار روی سرور

# بخش اول — مشاوره ارشد فنی

## معماری سه‌لایه
1. **رابط کاربری:** React + TypeScript + Vite، با موتور OCR آفلاین داخل مرورگر. خروجی نهایی فایل استاتیک است.
2. **سرور:** Node.js + Express 5 — احراز هویت، نقش‌ها، لایسنس، تیکت، API.
3. **دیتابیس:** MySQL 8 یا MariaDB؛ هر رکورد به سازمان (workspace) مقید است.

لایه داده دو راننده با یک قرارداد دارد: MySQL برای تولید، حافظه برای تست. کد تجاری فرقی نمی‌کند به کدام وصل باشد.

## اگر امروز می‌ساختم، همین استک را نگه می‌داشتم
| لایه | انتخاب | چرا |
|---|---|---|
| فرانت | React + TS + Vite + Tailwind | اکوسیستم بزرگ، تایپ استاتیک، استخدام آسان |
| OCR | Tesseract.js آفلاین | اسناد مالی از دستگاه خارج نمی‌شوند؛ مزیت اعتمادی فروش سازمانی |
| سرور | Node + Express | هم‌زبانی با فرانت، هزینه نگه‌داری پایین |
| دیتابیس | MySQL | داده رابطه‌ای، پشتیبان‌گیری و نیروی متخصص فراوان |
| احراز | JWT کوتاه + Refresh چرخشی + TOTP | استاندارد صنعت، بدون سشن حافظه‌ای |

- **چرا PHP نه؟** XAMPP اینجا فقط برای MySQL استفاده می‌شود؛ Apache نقشی ندارد چون سرور Node است و یکدستی زبان جاوااسکریپت مهم‌تر است.
- **مراحل مقیاس‌پذیری آینده:** بکاپ خودکار ← HTTPS ← PM2 ← Read Replica ← کش Redis ← مانیتورینگ.

# بخش دوم — استقرار عملی

## الف) کامپیوتر شخصی ویندوز با XAMPP
مطابق `README-START-HERE.txt`: نصب XAMPP و Node 22 ← Start دادن MySQL ← اجرای `setup.bat` ← اجرای `start.bat` ← باز شدن `http://localhost:8787`.

روش دستی به‌جای setup.bat:
1. در phpMyAdmin → Import → فایل `database/schema-mariadb.sql`.
2. خط فرمان داخل پوشه برنامه:
```
cd server
npm install --omit=dev
cd ..
node --env-file=.env server/src/index.js
```

## ب) سرور واقعی اینترنت (VPS اوبونتو) — توصیه‌شده برای فروش

### ب-۱) سرور و دامنه
VPS با Ubuntu 24.04، حداقل ۲ هسته/۴ گیگ RAM. رکورد A دامنه (مثلا `app.yourdomain.ir`) به IP سرور.

### ب-۲) اتصال و امن‌سازی پایه
```bash
ssh root@IP_SERVER
apt update && apt upgrade -y
apt install -y curl ufw
ufw allow OpenSSH && ufw allow 'Nginx Full' && ufw --force enable
```

### ب-۳) MySQL
```bash
apt install -y mysql-server
mysql_secure_installation
mysql -u root -p
```
داخل MySQL:
```sql
CREATE DATABASE faktorizm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'faktorizm'@'localhost' IDENTIFIED BY 'YOUR_STRONG_DB_PASSWORD';
GRANT ALL PRIVILEGES ON faktorizm.* TO 'faktorizm'@'localhost';
FLUSH PRIVILEGES; EXIT;
```

### ب-۴) Node 22
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
```

### ب-۵) آپلود و نصب
از کامپیوتر خودتان:
```bash
scp -r faktorizm-xampp root@IP_SERVER:/opt/faktorizm
```
روی سرور:
```bash
cd /opt/faktorizm/server && npm install --omit=dev && cd ..
mysql -u faktorizm -p faktorizm < database/schema-mariadb.sql
```

### ب-۶) فایل .env
```bash
nano /opt/faktorizm/.env
```
مقادیر مهم: `DB_DRIVER=mysql`، رمز دیتابیس، `CORS_ORIGINS=https://app.yourdomain.ir`، `WEB_DIR=web`، ایمیل و رمز اولیه مدیر.
ساخت کلید JWT:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

### ب-۷) PM2 (روشن شدن خودکار بعد از ری‌بوت)
```bash
npm install -g pm2
cd /opt/faktorizm
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup
```
دستور چاپ‌شده توسط `pm2 startup` را هم اجرا کنید.

### ب-۸) Nginx به‌عنوان دروازه
```bash
apt install -y nginx
nano /etc/nginx/sites-available/faktorizm
```
محتوا:
```nginx
server {
    listen 80;
    server_name app.yourdomain.ir;
    client_max_body_size 5m;
    location / {
        proxy_pass http://127.0.0.1:8787;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
فعال‌سازی:
```bash
ln -s /etc/nginx/sites-available/faktorizm /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### ب-۹) HTTPS رایگان
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d app.yourdomain.ir
certbot renew --dry-run
```

### ب-۱۰) بکاپ خودکار شبانه
```bash
mkdir -p /var/backups/faktorizm
nano /opt/faktorizm/backup.sh
```
محتوا:
```bash
#!/bin/bash
DATE=$(date +%F)
mysqldump -u faktorizm -p'YOUR_STRONG_DB_PASSWORD' faktorizm | gzip > /var/backups/faktorizm/faktorizm-$DATE.sql.gz
find /var/backups/faktorizm -name "*.sql.gz" -mtime +14 -delete
```
زمان‌بندی:
```bash
chmod +x /opt/faktorizm/backup.sh
(crontab -l 2>/dev/null; echo "30 2 * * * /opt/faktorizm/backup.sh") | crontab -
```

## ج) هاست اشتراکی cPanel — صادقانه
- هاست فقط PHP/MySQL: **کار نمی‌کند** چون سرور Node است.
- هاست دارای «Setup Node.js App»: قابل اجرا — دیتابیس و کاربر را در MySQL Databases بسازید، اسکیما را از phpMyAdmin ایمپورت، اپ Node 22 با ریشه `server` و فایل شروع `src/index.js` بسازید، متغیرهای `.env` را در فرم cPanel تک‌تک وارد کنید، Run NPM Install بزنید و SSL را فعال کنید.
- توصیه: برای محصول فروخته‌شده VPS هم ارزان‌تر هم مطمئن‌تر است.

## عیب‌یابی
| نشانه | علت | راه‌حل |
|---|---|---|
| «ارتباط با سرور برقرار نشد» | سرور خاموش | `pm2 status` یا `start.bat` |
| خطای دیتابیس هنگام بوت | MySQL خاموش/رمز اشتباه | چک `.env` و سرویس MySQL |
| صفحه سفید بعد از آپدیت | کش/SW قدیمی | Ctrl+F5؛ سرویس‌ورک v2 خودش کش قدیمی را پاک می‌کند |
| «منشا در فهرست مجاز نیست» | دامنه در CORS_ORIGINS نیست | افزودن دامنه و ری‌استارت |
| ورود قفل شد | ۵ رمز اشتباه | ۱۵ دقیقه صبر یا `LOCK_MINUTES` |
| آپلود بزرگ رد می‌شود | سقف JSON_LIMIT / nginx | هر دو را هماهنگ بزرگ کنید |

## به‌روزرسانی نسخه بعدی
بکاپ ← جایگزینی `web` و `server/src` (دست‌نزدن به `.env` و `data`) ← `npm install --omit=dev در صورت نیاز` ← اجرای migration در صورت تغییر اسکیما ← `pm2 restart faktorizm` ← Ctrl+F5 در مرورگر.

— سعید سالاری · فاکتوریزم نسخه ۲.۰
