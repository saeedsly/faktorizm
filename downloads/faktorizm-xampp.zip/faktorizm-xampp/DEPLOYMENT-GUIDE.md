# راهنمای جامع فاکتوریزم — تصمیم فنی و استقرار روی سرور

# بخش اول — مشاوره ارشد فنی

## معماری سه‌لایه
1. **رابط کاربری:** React + TypeScript + Vite؛ ابتدا سرویس قوی OCR را صدا می‌زند و اگر در دسترس نبود بی‌سروصدا به موتور آفلاین داخل مرورگر (Tesseract) برمی‌گردد. خروجی نهایی فایل استاتیک است.
2. **سرور:** Node.js + Express 5 — احراز هویت، نقش‌ها، لایسنس، تیکت، API و پروکسی OCR. کنار آن سرویس محلی پایتون (RapidOCR + PP-OCRv5 عربی/فارسی، فقط روی 127.0.0.1) اجرا می‌شود؛ مدل‌ها داخل بسته‌اند و هیچ ارتباط اینترنتی ندارد.
3. **دیتابیس:** MySQL 8 یا MariaDB؛ هر رکورد به سازمان (workspace) مقید است.

لایه داده دو راننده با یک قرارداد دارد: MySQL برای تولید، حافظه برای تست. کد تجاری فرقی نمی‌کند به کدام وصل باشد.

## اگر امروز می‌ساختم، همین استک را نگه می‌داشتم
| لایه | انتخاب | چرا |
|---|---|---|
| فرانت | React + TS + Vite + Tailwind | اکوسیستم بزرگ، تایپ استاتیک، استخدام آسان |
| OCR | سرویس محلی RapidOCR PP-OCRv5 (خط لوله چندنسخه‌ای) + Tesseract.js به‌عنوان fallback + لایه ابری اختیاری | دقت بالا در ارقام و متون فارسی/عربی، مدل‌های بسته‌بندی‌شده، پیش‌فرض کاملاً محلی |
| سرور | Node + Express | هم‌زبانی با فرانت، هزینه نگه‌داری پایین |
| دیتابیس | MySQL | داده رابطه‌ای، پشتیبان‌گیری و نیروی متخصص فراوان |
| احراز | JWT کوتاه + Refresh چرخشی + TOTP | استاندارد صنعت، بدون سشن حافظه‌ای |

- **چرا PHP نه؟** XAMPP اینجا فقط برای MySQL استفاده می‌شود؛ Apache نقشی ندارد چون سرور Node است و یکدستی زبان جاوااسکریپت مهم‌تر است.
- **مراحل مقیاس‌پذیری آینده:** بکاپ خودکار ← HTTPS ← PM2 ← Read Replica ← کش Redis ← مانیتورینگ.

# بخش دوم — استقرار عملی

## پیشرفت‌های تازه این نسخه
- برش خودکار قاب سند و تصحیح پرسپکتیو در `src/lib/ocr/autocrop.ts` (تشخیص گوشه‌های کاغذ، هوموگرافی چهارنقطه‌ای، سنجش تاری/نور/بازتاب).
- اثر انگشت فایل و کش خوانش در `src/lib/ocr/fingerprint.ts` و `src/lib/ocr/cache.ts`؛ فایل تکراری بدون اجرای دوباره موتور خوانده می‌شود.
- جدا کردن چند سند از یک فایل در `src/lib/ocr/splitter.ts`؛ اسناد اضافی به‌صورت پیش‌نویس ذخیره می‌شوند.
- صف پردازش پایدار و اولویت‌دار در `src/hooks/useOcrQueue.ts` (ذخیره در IndexedDB، توقف/لغو/تلاش دوباره، تخمین زمان).
- جستجوی هوشمند و تحلیل الگوها در `src/lib/invoices/insights.ts`؛ تاریخچه، نسخه‌ها و اقساط در `src/lib/invoices/workflow.ts`؛ دانش فروشنده در `src/lib/vendors.ts`.
- موتور اقلام در `src/lib/ocr/items.ts` بازنویسی شد: هر خط متن یک نقش می‌گیرد (عنوان، ردیف اعداد، سرستون، جمع‌بندی، شناسنامه، تبلیغ، تعداد، نویز)، واژه‌نامه اصناف در `src/lib/ocr/lexicon.ts` و پایه‌های مشترک در `src/lib/ocr/primitives.ts` قرار گرفت. «فهم نوشتاری» (`freetext.ts`) اکنون روکش نازکی روی همین موتور است؛ نتیجه اینکه خطوط تبلیغ/آدرس/تلفن هرگز داخل عنوان کالا نمی‌روند. پنل «هوش اقلام» در صفحه ویرایش سند اطمینان هر قلم، دلیل هر تصمیم، جایگزین‌های ردیف، ردیف گمشده، کیفیت ستون‌ها و تعیین دستی نقش خط را نشان می‌دهد. آزمون‌ها: `npm run test:items` و `npm run test:freetext`.
- پایگاه داده محلی به نسخه ۲ ارتقا یافت (جداول `audit`، `versions`، `paymentPlans`، `vendors`، `ocrCache`، `aiCache`، `usage`، `queue`)؛ ارتقا خودکار است و داده قبلی حفظ می‌شود.

## الف) کامپیوتر شخصی ویندوز با XAMPP
مطابق `README-START-HERE.txt`: نصب XAMPP و Node 22 (و اختیاری Python 3.11) ← Start دادن MySQL ← اجرای `setup.bat` ← اجرای `start.bat` ← باز شدن `http://localhost:8787`.

فهم ساختار جدول در `ocr-service/table.py` انجام می‌شود: نقش هر عدد در ردیف با اعتبارسنجی ریاضی (تعداد × قیمت واحد − تخفیف + مالیات = مبلغ ردیف) تعیین می‌شود، بنابراین به قالب ظاهری فاکتور وابسته نیست؛ سطرهای جمع‌بندی و پانویس هم از اقلام جدا می‌شوند.

لایه دوم فهم، در مرورگر و مستقل از مختصات کار می‌کند (`src/lib/ocr/freetext.ts`): خط‌های متنی و عددی متن خام را کنار هم می‌گذارد، عنوان کالا را از خط بالای اعداد می‌شناسد، نقش هر عدد را با معادله ردیف تعیین می‌کند، خطوط شناسنامه‌ای (تلفن، کد اقتصادی، شماره مرجع) را حذف می‌کند و مبلغ نهایی چاپ‌شده روی سند را در فاکتور نگه می‌دارد. اگر جمع ردیف‌ها با مبلغ سند نخواند، همان مبلغ سند مرجع می‌شود و در خلاصه سند هشدار داده می‌شود. آزمون این لایه: `npm run test:freetext`.

خط لوله سرویس محلی در `ocr-service/pipeline.py` است: تصویر بزرگ‌نمایی می‌شود، نویز و کجی اصلاح می‌شود، دو نسخه تیز و باینری خوانده می‌شود، جعبه‌های هم‌مکان ادغام می‌شوند، جعبه‌های کم‌اطمینان با حاشیه بازخوانی می‌شوند و در پایان هر خط از راست به چپ بازسازی و با `textfix.py` تصحیح می‌شود (نرمال‌سازی نویسه‌های عربی/فارسی، ترتیب منطقی واژه‌ها و واژه‌نامه فاکتور).

`setup.bat` در پوشه `ocr-service` یک محیط مجازی پایتون می‌سازد و وابستگی‌ها را نصب می‌کند: اگر پوشه `ocr-service\wheels` (فایل‌های `.whl`) موجود باشد کاملا آفلاین، وگرنه از PyPI دانلود می‌کند. `start.bat` سرویس OCR را در یک پنجره کوچک‌شده روی `127.0.0.1:8789` بالا می‌آورد و بعد سرور Node را اجرا می‌کند. نبود پایتون خطا نیست؛ برنامه به موتور مرورگر fallback می‌کند.

روش دستی به‌جای setup.bat:
1. در phpMyAdmin → Import → فایل `database/schema-mariadb.sql`.
2. خط فرمان داخل پوشه برنامه:
```
cd server
npm install --omit=dev
cd ..\ocr-service
py -3.11 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
cd ..
node --env-file=.env server/src/index.js
```
و در یک پنجره جداگانه برای موتور قوی:
```
ocr-service\.venv\Scripts\python ocr-service\service.py
```

## ب) سرور واقعی اینترنت (VPS اوبونتو) — توصیه‌شده برای فروش

### ب-۱) سرور و دامنه
VPS با Ubuntu 24.04، حداقل ۲ هسته/۴ گیگ RAM. رکورد A دامنه (مثلا `app.yourdomain.ir`) به IP سرور.

### ب-۲) اتصال و امن‌سازی پایه
```bash
ssh root@IP_SERVER
apt update && apt upgrade -y
apt install -y curl ufw
ufw allow OpenSSH && ufw allow 'Nginx Full' && ufw --force enable
```

### ب-۳) MySQL
```bash
apt install -y mysql-server
mysql_secure_installation
mysql -u root -p
```
داخل MySQL:
```sql
CREATE DATABASE faktorizm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'faktorizm'@'localhost' IDENTIFIED BY 'YOUR_STRONG_DB_PASSWORD';
GRANT ALL PRIVILEGES ON faktorizm.* TO 'faktorizm'@'localhost';
FLUSH PRIVILEGES; EXIT;
```

### ب-۴) Node 22 و Python
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs python3 python3-venv python3-pip
```

### ب-۵) آپلود و نصب
از کامپیوتر خودتان:
```bash
scp -r faktorizm-xampp root@IP_SERVER:/opt/faktorizm
```
روی سرور:
```bash
cd /opt/faktorizm/server && npm install --omit=dev && cd ..
mysql -u faktorizm -p faktorizm < database/schema-mariadb.sql

# سرویس محلی OCR (مدل‌ها داخل ocr-service/models همراه بسته‌اند)
cd /opt/faktorizm/ocr-service
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
cd /opt/faktorizm
```

### ب-۶) فایل .env
```bash
nano /opt/faktorizm/.env
```
مقادیر مهم: `DB_DRIVER=mysql`، رمز دیتابیس، `CORS_ORIGINS=https://app.yourdomain.ir`، `WEB_DIR=web`، ایمیل و رمز اولیه مدیر.
ساخت کلید JWT:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

### ب-۷) PM2 (روشن شدن خودکار بعد از ری‌بوت)
```bash
npm install -g pm2
cd /opt/faktorizm
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup
```
دستور چاپ‌شده توسط `pm2 startup` را هم اجرا کنید.

### ب-۸) Nginx به‌عنوان دروازه
```bash
apt install -y nginx
nano /etc/nginx/sites-available/faktorizm
```
محتوا:
```nginx
server {
    listen 80;
    server_name app.yourdomain.ir;
    client_max_body_size 25m;
    location / {
        proxy_pass http://127.0.0.1:8787;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
فعال‌سازی:
```bash
ln -s /etc/nginx/sites-available/faktorizm /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### ب-۹) HTTPS رایگان
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d app.yourdomain.ir
certbot renew --dry-run
```

### ب-۱۰) بکاپ خودکار شبانه
```bash
mkdir -p /var/backups/faktorizm
nano /opt/faktorizm/backup.sh
```
محتوا:
```bash
#!/bin/bash
DATE=$(date +%F)
mysqldump -u faktorizm -p'YOUR_STRONG_DB_PASSWORD' faktorizm | gzip > /var/backups/faktorizm/faktorizm-$DATE.sql.gz
find /var/backups/faktorizm -name "*.sql.gz" -mtime +14 -delete
```
زمان‌بندی:
```bash
chmod +x /opt/faktorizm/backup.sh
(crontab -l 2>/dev/null; echo "30 2 * * * /opt/faktorizm/backup.sh") | crontab -
```

## ج) هاست اشتراکی cPanel — صادقانه
- هاست فقط PHP/MySQL: **کار نمی‌کند** چون سرور Node است.
- هاست دارای «Setup Node.js App»: قابل اجرا — دیتابیس و کاربر را در MySQL Databases بسازید، اسکیما را از phpMyAdmin ایمپورت، اپ Node 22 با ریشه `server` و فایل شروع `src/index.js` بسازید، متغیرهای `.env` را در فرم cPanel تک‌تک وارد کنید، Run NPM Install بزنید و SSL را فعال کنید.
- توصیه: برای محصول فروخته‌شده VPS هم ارزان‌تر هم مطمئن‌تر است.

## عیب‌یابی
| نشانه | علت | راه‌حل |
|---|---|---|
| «ارتباط با سرور برقرار نشد» | سرور خاموش | `pm2 status` یا `start.bat` |
| خطای دیتابیس هنگام بوت | MySQL خاموش/رمز اشتباه | چک `.env` و سرویس MySQL |
| صفحه سفید بعد از آپدیت | کش/SW قدیمی | Ctrl+F5؛ سرویس‌ورک v2 خودش کش قدیمی را پاک می‌کند |
| «منشا در فهرست مجاز نیست» | دامنه در CORS_ORIGINS نیست | افزودن دامنه و ری‌استارت |
| ورود قفل شد | ۵ رمز اشتباه | ۱۵ دقیقه صبر یا `LOCK_MINUTES` |
| موتور ابری خطا می‌دهد | کلید API، نام مدل یا اینترنت | در تنظیمات دکمه «آزمون اتصال کلید» را بزنید؛ خوانش محلی در هر حالت انجام می‌شود و سند بی‌نتیجه نمی‌ماند |
| آپلود بزرگ رد می‌شود | سقف JSON_LIMIT / nginx | هر دو را هماهنگ بزرگ کنید (تصویر OCR تا ۲۵ مگابایت مجاز است) |
| هشدار «با موتور داخلی خوانده شد» | سرویس پایتون بالا نیست | وضعیت پورت 8789؛ روی ویندوز `start.bat` و روی سرور `pm2 status`؛ لاگ `faktorizm-ocr` |
| خطای import rapidocr هنگام بوت | نصب ناقص venv | دوباره `pip install -r requirements.txt` (یا نصب آفلاین از `wheels`) |

## به‌روزرسانی نسخه بعدی
بکاپ ← جایگزینی `web`، `server/src` و در صورت نیاز `ocr-service` (مدل‌ها و `service.py`؛ دست‌نزدن به `.venv`، `.env` و `data`) ← `npm install --omit=dev` و `.venv/bin/pip install -r ocr-service/requirements.txt` در صورت تغییر وابستگی ← اجرای migration در صورت تغییر اسکیما ← `pm2 restart faktorizm-ocr faktorizm` ← Ctrl+F5 در مرورگر.

— سعید سالاری · فاکتوریزم نسخه ۲.۰
