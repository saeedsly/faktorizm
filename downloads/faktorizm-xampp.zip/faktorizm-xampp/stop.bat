@echo off
setlocal enableextensions
title Faktorizm - Stop server

echo Stopping the server on port 8787 ...
set "FOUND=0"
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":8787" ^| findstr "LISTENING"') do (
  taskkill /F /PID %%p >nul 2>nul
  set "FOUND=1"
)
if "%FOUND%"=="0" (
  echo No server was listening on port 8787.
) else (
  echo Server stopped.
)
pause
