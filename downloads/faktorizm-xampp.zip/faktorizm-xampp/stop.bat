@echo off
chcp 65001 >nul
title توقف سرور فاکتوریزم

echo در حال توقف سرور روی پورت 8787 ...
set "FOUND=0"
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":8787" ^| findstr "LISTENING"') do (
  taskkill /F /PID %%p >nul 2>nul
  set "FOUND=1"
)
if "%FOUND%"=="0" (
  echo سروری روی پورت 8787 در حال اجرا نبود.
) else (
  echo سرور متوقف شد.
)
pause
