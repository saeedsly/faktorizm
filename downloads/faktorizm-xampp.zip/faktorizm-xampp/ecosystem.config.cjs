// پیکربندی PM2 برای استقرار روی سرور لینوکسی
// اجرا:  pm2 start ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [
    {
      name: 'faktorizm',
      script: 'server/src/index.js',
      cwd: __dirname,
      node_args: '--env-file=.env',
      autorestart: true,
      max_restarts: 10,
      max_memory_restart: '500M',
      env: { NODE_ENV: 'production' },
    },
  ],
};
