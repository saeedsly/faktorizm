// پیکربندی PM2 برای استقرار روی سرور لینوکسی
// اجرا:  pm2 start ecosystem.config.cjs && pm2 save
//
// پیش‌نیاز موتور OCR روی لینوکس:
//   cd ocr-service
//   python3 -m venv .venv
//   .venv/bin/pip install -r requirements.txt        # یا از wheels به‌صورت آفلاین
const path = require('path');

module.exports = {
  apps: [
    {
      name: 'faktorizm-ocr',
      script: 'service.py',
      cwd: path.join(__dirname, 'ocr-service'),
      interpreter: path.join(__dirname, 'ocr-service', '.venv', 'bin', 'python'),
      autorestart: true,
      max_restarts: 10,
      max_memory_restart: '800M',
      env: { OCR_PORT: '8789', NODE_ENV: 'production' },
    },
    {
      name: 'faktorizm',
      script: 'server/src/index.js',
      cwd: __dirname,
      node_args: '--env-file=.env',
      autorestart: true,
      max_restarts: 10,
      max_memory_restart: '500M',
      env: { NODE_ENV: 'production', OCR_PORT: '8789' },
    },
  ],
};
