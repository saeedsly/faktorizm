@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title نصب اولیه فاکتوریزم
cd /d "%~dp0"

echo ============================================================
echo   نصب اولیه فاکتوریزم — لطفا این پنجره را تا پایان نبندید
echo ============================================================
echo.

echo [1/4] بررسی نصب Node.js ...
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  X Node.js روی این سیستم نصب نیست.
  echo     از آدرس https://nodejs.org نسخه LTS را دانلود و نصب کنید،
  echo     سپس دوباره همین فایل setup.bat را اجرا کنید.
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo     نسخه نصب‌شده: %%v
echo.

echo [2/4] نصب کتابخانه‌های سرور (چند دقیقه طول می‌کشد) ...
cd server
call npm install --omit=dev
if errorlevel 1 (
  echo  X نصب کتابخانه‌ها شکست خورد. اتصال اینترنت را بررسی کنید.
  pause
  exit /b 1
)
cd ..
echo.

echo [3/4] پیدا کردن MySQL مربوط به XAMPP ...
set "MYSQL_BIN="
if exist "C:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=C:\xampp\mysql\bin\mysql.exe"
if exist "D:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=D:\xampp\mysql\bin\mysql.exe"
if not defined MYSQL_BIN (
  where mysql >nul 2>nul && set "MYSQL_BIN=mysql"
)
if not defined MYSQL_BIN (
  echo  X mysql.exe پیدا نشد.
  echo     مطمئن شوید XAMPP در مسیر پیش‌فرض نصب است، یا MySQL را به PATH اضافه کنید.
  echo     می‌توانید اسکیمای database\schema-mariadb.sql را هم دستی از phpMyAdmin ایمپورت کنید.
  pause
  exit /b 1
)
echo     مسیر: !MYSQL_BIN!
echo.

rem خواندن رمز MySQL از فایل .env (پیش‌فرض XAMPP رمز ندارد)
set "MPWD="
for /f "tokens=1,* delims==" %%a in ('findstr /b "MYSQL_PASSWORD=" .env') do set "MPWD=%%b"
if defined MPWD (set "PWDARG=-p!MPWD!") else (set "PWDARG=")

echo     بررسی روشن بودن سرویس MySQL در XAMPP ...
"%MYSQL_BIN%" -u root !PWDARG! -e "SELECT 1;" >nul 2>nul
if errorlevel 1 (
  echo  X اتصال به MySQL برقرار نشد.
  echo     XAMPP Control Panel را باز کنید و روی Start مقابل MySQL بزنید، سپس دوباره اجرا کنید.
  pause
  exit /b 1
)

echo     ساخت دیتابیس و جدول‌ها ...
"%MYSQL_BIN%" -u root !PWDARG! < database\schema-mariadb.sql
if errorlevel 1 (
  echo  X ایمپورت اسکیمای دیتابیس شکست خورد.
  pause
  exit /b 1
)
echo.

echo [4/4] ساخت کلید محرمانه JWT داخل فایل .env ...
node -e "const fs=require('fs'),c=require('crypto');let e=fs.readFileSync('.env','utf8');if(e.includes('__JWT_SECRET__')){e=e.replace('__JWT_SECRET__',c.randomBytes(48).toString('hex'));fs.writeFileSync('.env',e);console.log('     کلید ساخته و ذخیره شد.')}else{console.log('     کلید قبلا ساخته شده؛ دست نخورد.')}"
echo.

echo ============================================================
echo   نصب کامل شد.
echo   برای اجرای برنامه روی فایل start.bat دابل‌کلیک کنید.
echo   اطلاعات ورود اولیه:
echo      ایمیل: admin@faktorizm.ir
echo      رمز:   Admin@1405
echo ============================================================
pause
