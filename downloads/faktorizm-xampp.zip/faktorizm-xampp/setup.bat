@echo off
setlocal enableextensions
title Faktorizm - First-time setup
cd /d "%~dp0"

echo ============================================================
echo   Faktorizm - First-time setup
echo   Please keep this window open until it finishes.
echo ============================================================
echo.

echo [1/5] Checking Node.js ...
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERROR] Node.js is not installed.
  echo  Download the LTS version from https://nodejs.org
  echo  install it, then run setup.bat again.
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo     Node version: %%v
echo.

echo [2/5] Installing server packages, this can take a few minutes ...
pushd server
call npm install --omit=dev
if errorlevel 1 (
  popd
  echo.
  echo  [ERROR] npm install failed. Check your internet connection and retry.
  echo.
  pause
  exit /b 1
)
popd
echo.

echo [3/5] Preparing the local OCR engine (Python PP-OCRv5) ...
set "PYTHON_CMD="
py -3.11 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3.11"
if not defined PYTHON_CMD (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD goto :no_python

%PYTHON_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 (
  echo  [WARN] Python 3.10 or newer is required for the strong OCR engine.
  goto :no_python
)

if exist "ocr-service\.venv\Scripts\python.exe" (
  echo     Python virtual environment already exists, keeping it.
) else (
  pushd ocr-service
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (
    popd
    echo  [WARN] Could not create the Python virtual environment.
    goto :no_python_popd
  )
  if exist "wheels\*.whl" (
    echo     Installing OCR packages offline from the bundled wheels ...
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links wheels -r requirements-lock.txt
  ) else (
    echo     Downloading OCR packages from PyPI ...
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  )
  if errorlevel 1 (
    popd
    echo  [WARN] OCR package installation failed.
    goto :no_python_popd
  )
  ".venv\Scripts\python.exe" -c "import rapidocr, onnxruntime; print('    OCR engine OK')"
  if errorlevel 1 (
    popd
    echo  [WARN] OCR engine self-test failed.
    goto :no_python_popd
  )
  popd
)
echo     Strong OCR engine is ready (fully offline, models are bundled).
goto :python_done

:no_python_popd
popd
:no_python
echo  [WARN] Python 3.10+ was not found. The app will still work and use the
echo         built-in browser OCR engine (Tesseract). To enable the stronger
echo         PP-OCRv5 engine, install Python 3.11 from https://www.python.org
echo         ^(tick "Add python.exe to PATH"^) and run setup.bat again.
:python_done
echo.

echo [4/5] Locating MySQL from XAMPP ...
set "MYSQL_BIN="
if exist "C:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=C:\xampp\mysql\bin\mysql.exe"
if exist "D:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=D:\xampp\mysql\bin\mysql.exe"
if not defined MYSQL_BIN (
  where mysql >nul 2>nul
  if not errorlevel 1 set "MYSQL_BIN=mysql"
)
if not defined MYSQL_BIN (
  echo.
  echo  [ERROR] mysql.exe was not found.
  echo  Make sure XAMPP is installed in the default folder, or add MySQL to PATH.
  echo  You can also import database\schema-mariadb.sql manually through phpMyAdmin.
  echo.
  pause
  exit /b 1
)
echo     MySQL client: %MYSQL_BIN%
echo.

rem Read MySQL password from .env (default XAMPP root has an empty password)
set "MPWD="
for /f "tokens=1,* delims==" %%a in ('findstr /b "MYSQL_PASSWORD=" .env') do set "MPWD=%%b"
if defined MPWD (set "PWDARG=-p%MPWD%") else (set "PWDARG=")

echo     Checking MySQL connection ...
"%MYSQL_BIN%" -u root %PWDARG% -e "SELECT 1;" >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERROR] Cannot connect to MySQL.
  echo  Open the XAMPP Control Panel, click Start next to MySQL, then run setup.bat again.
  echo.
  pause
  exit /b 1
)

echo     Creating database and tables ...
"%MYSQL_BIN%" -u root %PWDARG% < database\schema-mariadb.sql
if errorlevel 1 (
  echo.
  echo  [ERROR] Database schema import failed.
  echo.
  pause
  exit /b 1
)
echo.

echo [5/5] Generating the JWT secret inside .env ...
node -e "const fs=require('fs'),c=require('crypto');let e=fs.readFileSync('.env','utf8');if(e.includes('__JWT_SECRET__')){e=e.replace('__JWT_SECRET__',c.randomBytes(48).toString('hex'));fs.writeFileSync('.env',e);console.log('     Secret generated and saved.')}else{console.log('     Secret already exists, kept unchanged.')}"
echo.

echo ============================================================
echo   Setup complete.
echo.
echo   Next step: double-click start.bat to launch the app.
echo.
echo   First-time login:
echo      Email:    admin@faktorizm.ir
echo      Password: Admin@1405
echo ============================================================
echo.
pause
