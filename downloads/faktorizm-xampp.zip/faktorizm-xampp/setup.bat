@echo off
setlocal enableextensions
title Faktorizm - First-time setup
cd /d "%~dp0"

echo ============================================================
echo   Faktorizm - First-time setup
echo   Please keep this window open until it finishes.
echo ============================================================
echo.

echo [1/4] Checking Node.js ...
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERROR] Node.js is not installed.
  echo  Download the LTS version from https://nodejs.org
  echo  install it, then run setup.bat again.
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo     Node version: %%v
echo.

echo [2/4] Installing server packages, this can take a few minutes ...
pushd server
call npm install --omit=dev
if errorlevel 1 (
  popd
  echo.
  echo  [ERROR] npm install failed. Check your internet connection and retry.
  echo.
  pause
  exit /b 1
)
popd
echo.

echo [3/4] Locating MySQL from XAMPP ...
set "MYSQL_BIN="
if exist "C:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=C:\xampp\mysql\bin\mysql.exe"
if exist "D:\xampp\mysql\bin\mysql.exe" set "MYSQL_BIN=D:\xampp\mysql\bin\mysql.exe"
if not defined MYSQL_BIN (
  where mysql >nul 2>nul
  if not errorlevel 1 set "MYSQL_BIN=mysql"
)
if not defined MYSQL_BIN (
  echo.
  echo  [ERROR] mysql.exe was not found.
  echo  Make sure XAMPP is installed in the default folder, or add MySQL to PATH.
  echo  You can also import database\schema-mariadb.sql manually through phpMyAdmin.
  echo.
  pause
  exit /b 1
)
echo     MySQL client: %MYSQL_BIN%
echo.

rem Read MySQL password from .env (default XAMPP root has an empty password)
set "MPWD="
for /f "tokens=1,* delims==" %%a in ('findstr /b "MYSQL_PASSWORD=" .env') do set "MPWD=%%b"
if defined MPWD (set "PWDARG=-p%MPWD%") else (set "PWDARG=")

echo     Checking MySQL connection ...
"%MYSQL_BIN%" -u root %PWDARG% -e "SELECT 1;" >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERROR] Cannot connect to MySQL.
  echo  Open the XAMPP Control Panel, click Start next to MySQL, then run setup.bat again.
  echo.
  pause
  exit /b 1
)

echo     Creating database and tables ...
"%MYSQL_BIN%" -u root %PWDARG% < database\schema-mariadb.sql
if errorlevel 1 (
  echo.
  echo  [ERROR] Database schema import failed.
  echo.
  pause
  exit /b 1
)
echo.

echo [4/4] Generating the JWT secret inside .env ...
node -e "const fs=require('fs'),c=require('crypto');let e=fs.readFileSync('.env','utf8');if(e.includes('__JWT_SECRET__')){e=e.replace('__JWT_SECRET__',c.randomBytes(48).toString('hex'));fs.writeFileSync('.env',e);console.log('     Secret generated and saved.')}else{console.log('     Secret already exists, kept unchanged.')}"
echo.

echo ============================================================
echo   Setup complete.
echo.
echo   Next step: double-click start.bat to launch the app.
echo.
echo   First-time login:
echo      Email:    admin@faktorizm.ir
echo      Password: Admin@1405
echo ============================================================
echo.
pause
