@echo off
setlocal enableextensions
title Faktorizm - Node server
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)

if not exist "web\index.html" (
  echo [ERROR] web\index.html is missing. Extract the whole zip again.
  pause
  exit /b 1
)

if not exist "server\node_modules\express" (
  echo Server packages are missing, running setup.bat once ...
  call setup.bat
  if errorlevel 1 exit /b 1
)

echo ============================================================
echo   Faktorizm is starting ...
echo.
echo   App URL : http://localhost:8787
echo   Keep this window open while using the app.
echo   To stop : close this window or press Ctrl+C.
echo ============================================================
echo.

start "" /min cmd /c "timeout /t 4 /nobreak >nul & explorer http://localhost:8787"
node --env-file=.env server/src/index.js

echo.
echo Server stopped.
pause
