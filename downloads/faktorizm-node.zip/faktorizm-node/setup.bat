@echo off
setlocal enableextensions
title Faktorizm - Setup (Node option)
cd /d "%~dp0"

echo ============================================================
echo   Faktorizm - first-time setup (Node option)
echo ============================================================
echo.

echo [1/3] Checking Node.js ...
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERROR] Node.js is not installed.
  echo  Install the LTS version from https://nodejs.org then run setup.bat again.
  echo  This package needs Windows 10 or 11 for Node.js 20+.
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do echo     Node version: %%v
echo.

echo [2/3] Checking server packages ...
if exist "server\node_modules\express" (
  echo     Already included in this package. Nothing to download.
  goto :web_check
)
pushd server
call npm install --omit=dev --no-audit --no-fund
if errorlevel 1 (
  popd
  echo.
  echo  [ERROR] npm install failed. Check the internet connection and retry.
  echo.
  pause
  exit /b 1
)
popd
echo.

:web_check
echo [3/3] Checking the user interface ...
if not exist "web\index.html" (
  echo  [ERROR] web\index.html is missing. Extract the whole zip again.
  pause
  exit /b 1
)
echo     OK
echo.
echo ============================================================
echo   Setup finished. Now run start.bat
echo   App URL: http://localhost:8787
echo   Login  : admin@faktorizm.ir / Admin@1405
echo ============================================================
echo.
pause
